import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class BookList {
    private final ArrayList<Book> t;
    
    public BookList() {
        t = new ArrayList<>();
    }
    
    public void addBook(Book book) {
        if (searchBook(book.getCode()) == null) {
            t.add(book);
            System.out.println("Book added to the list.");
        } else {
            System.out.println("Book with the same code already exists in the list.");
        }
    }
    
    public void displayAllBooks() {
        if (t.isEmpty()) {
            System.out.println("Book list is empty.");
        } else {
            System.out.println("Book list:");
            t.forEach((book) -> {
                System.out.println(book);
            });
        }
    }
    
    public Book searchBook(String code) {
        for (Book b : t) {
            if (b.getCode().equals(code)) {
                return b;
            }
        }
        return null;
    }
    
    public void updateBookPriceByCode(String code, double price) {
        Book book = searchBook(code);
        if (book != null) {
            book.setPrice(price);
            System.out.println("Book with code " + code + " price updated.");
        }
    }
    
    public void findMaxPriceBook() {
        if (t.isEmpty()) {
            System.out.println("Book list is empty.");
            return;
        }
        double maxPrice = t.get(0).getPrice();
        Book maxPriceBook = t.get(0);
        for (Book book : t) {
            if (book.getPrice() > maxPrice) {
                maxPrice = book.getPrice();
                maxPriceBook = book;
            }
        }
        System.out.println("Book with the highest price: " + maxPriceBook);
    }
    
    public void sortBooksByCode() {
        Collections.sort(t, (Book b1, Book b2) -> b1.getCode().compareTo(b2.getCode()));
    }
    
    public void removeBookByCode(String code) {
        for (Book book : t) {
            if (book.getCode().equals(code)) {
                t.remove(book);
                System.out.println("Book with code " + code + " removed from the list.");
                return;
            }
        }
        System.out.println("Book with code " + code + " not found.");
    }
    
    public void loadDataFromFile(String fileName) {
        File file = new File(fileName);
        try (Scanner scanner = new Scanner(file)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                String[] tokens = line.split(",");
                if (tokens.length != 4) {
                    System.out.println("Invalid data in file " + fileName + ".");
                    return;
                }
                String code = tokens[0].trim();
                String title = tokens[1].trim();
                int qua = Integer.parseInt(tokens[2].trim());
                double price = Double.parseDouble(tokens[3].trim());
                Book book = new Book(code, title, qua, price);
                t.add(book);
            }
            System.out.println("Data loaded from file " + fileName + " successfully.");
        } catch (FileNotFoundException e) {
            System.out.println("File " + fileName + " not found.");
        } catch (NumberFormatException e) {
            System.out.println("Invalid data in file " + fileName + ".");
        }
    }
}
