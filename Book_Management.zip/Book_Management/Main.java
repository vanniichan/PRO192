import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        BookList bookList = new BookList();
        try (Scanner scanner = new Scanner(System.in)) {
            int option;
            do {
                System.out.println("Book Management System");
                System.out.println("1. Input & add book(s) to the end.");
                System.out.println("2. Display all books.");
                System.out.println("3. Search a book for given code.");
                System.out.println("4. Update the book's price for given code.");
                System.out.println("5. Find the (first) max price value.");
                System.out.println("6. Sort the list ascendingly by code.");
                System.out.println("7. Remove the book having given code.");
                System.out.println("8. Load data from file.");
                System.out.println("0. Exit.");
                System.out.print("Enter your option: ");
                option = scanner.nextInt();
                scanner.nextLine();
                switch (option) {
                    case 1:
                        System.out.print("Enter the number of books to add: ");
                        int n = scanner.nextInt();
                        scanner.nextLine();
                        for (int i = 0; i < n; i++) {
                            System.out.print("Enter the code of book " + (i+1) + ": ");
                            String code = scanner.nextLine();
                            System.out.print("Enter the title of book " + (i+1) + ": ");
                            String title = scanner.nextLine();
                            System.out.print("Enter the quantity of book " + (i+1) + ": ");
                            int qua = scanner.nextInt();
                            scanner.nextLine();
                            System.out.print("Enter the price of book " + (i+1) + ": ");
                            double price = scanner.nextDouble();
                            scanner.nextLine();
                            Book book = new Book(code, title, qua, price);
                            bookList.addBook(book);
                        }
                        System.out.println("Book(s) added to the list.");
                        break;
                    case 2:
                        bookList.displayAllBooks();
                        break;
                    case 3:
                        System.out.print("Enter the book code to search: ");
                    String code = scanner.next();
                    Book b = bookList.searchBook(code);
                    if (b != null) {
                        System.out.println(b.getCode() + " " + b.getTitle() + " " + b.getQua() + " " + b.getPrice());
                    } else {
                        System.out.println("Book with code " + code + " not found!");
                    }
                    break;
       
                    case 4:
                        System.out.print("Enter the code of the book to update: ");
                        String updateCode = scanner.nextLine();
                        System.out.print("Enter the new price of the book: ");
                        double updatePrice = scanner.nextDouble();
                        scanner.nextLine();
                        bookList.updateBookPriceByCode(updateCode, updatePrice);
                        break;
                    case 5:
                        bookList.findMaxPriceBook();
                        break;
                    case 6:
                        bookList.sortBooksByCode();
                        break;
                    case 7:
                        System.out.print("Enter the code of the book to remove: ");
                        String removeCode = scanner.nextLine();
                        bookList.removeBookByCode(removeCode);
                        break;
                    case 8:
                        System.out.print("Enter the file name to load data from: ");
                        String fileName = scanner.nextLine();
                        bookList.loadDataFromFile(fileName);
                        break;
                    case 0:
                        System.out.println("Exiting the program...");
                        break;
                    default:
                        System.out.println("Invalid option. Please try again.");
                }
                System.out.println();
            } while (option != 0);
        }
    }
}
